import java.util.Scanner;

public class BaiC {
	static boolean check = true;
	private static Scanner sc;

	static void init(int x[], int size) {
		for (int i = 1; i <= size; i++) {
			x[i] = i;
		}
	}

	static void result(int x[], int size) {
		for (int i = 1; i <= size; i++) {
			if (i==size) {
				System.out.print(x[i]);
			}else{
				System.out.print(x[i]+" ");
			}
			
		}
		System.out.println();
	}

	static void hoanVi(int x[], int size) {
		int j = size - 1;
		while (x[j] > x[j + 1]) {
			j--;
		}
		if (j == 0) {
			check = false;
		} else {
			int k = size;
			while (x[j] > x[k]) {
				k--;
			}
			int t = x[j];
			x[j] = x[k];
			x[k] = t;
			int s = j + 1, e = size;
			while (s < e) {
				int tmp = x[s];
				x[s] = x[e];
				x[e] = tmp;
				s++;
				e--;
			}
		}
	}

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		int size = sc.nextInt();
		int k = sc.nextInt();
		int[] x = new int[size + 1];
		int[][] mt = new int[size + 1][size + 1];
		int[][] r = new int[size + 1][size + 1];

		for (int i = 1; i <= size; i++) {
			for (int j = 1; j <= size; j++) {
				mt[i][j] = sc.nextInt();
			}
		}
		int dem = 1;
		init(x, size);
		while (check) {
			int total = 0;
			int i = 1;
			for (int j = 1; j <= size; j++) {
				total = total + mt[i][x[j]];
				i = i+1;
			}
			if (total == k) {
				for (int j = 1; j <= size; j++) {
					r[dem][j]= x[j];
				}
				dem++;
				
			}
			hoanVi(x, size);
		}
		System.out.println(dem-1);
		for (int i = 1; i <= dem-1; i++) {
			for (int j = 1; j <= size; j++) {
				if (j==size) {
					System.out.print(r[i][j]);
				}else{
					System.out.print(r[i][j]+" ");
				}
			}
			System.out.println();
		}

	}
}
