import java.util.Scanner;

public class BaiB {
	static boolean check = true;
	private static Scanner sc;

	static void init(int x[], int size, String values) {
		for (int i = 0; i < size; i++) {
			x[i] = Integer.valueOf(values.substring(i, i + 1));
		}
	}

	static void result(int x[], int size, int stt) {
		System.out.print(stt + " ");
		if (check) {
			for (int i = 0; i < size; i++) {
				System.out.print(x[i]);
			}
		} else {
			System.out.print("BIGGEST");
		}
	}

	static void hoanVi(int x[], int size) {
		int j = size - 2;
		while (j >= 0 && x[j] >= x[j + 1]) {
			j--;
		}
		if (j == -1) {
			check = false;
		} else {
			int k = size - 1;
			while (x[j] >= x[k]) {
				k--;
			}
			int t = x[j];
			x[j] = x[k];
			x[k] = t;
			int s = j + 1, e = size - 1;
			while (s < e) {
				int tmp = x[s];
				x[s] = x[e];
				x[e] = tmp;
				s++;
				e--;
			}
		}
	}

	public static void main(String[] args) {
		int t = 0;
		int b = 0;
		sc = new Scanner(System.in);
		b = Integer.valueOf(sc.nextLine());
		while (t < b) {
			String s = sc.nextLine();
			s = s.trim();
			String [] words = s.split("\\s+");
			int stt = Integer.valueOf(words[0]);
			int size = words[1].length();
			int[] x = new int[size];
			String values = words[1];
			init(x, size, values);
			hoanVi(x, size);
			result(x, size, stt);
			if (t<b-1) {
				System.out.println();
			}
			t++;
		}

	}
}
