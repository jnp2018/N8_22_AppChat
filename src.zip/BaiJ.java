
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class BaiJ {
    static long m=1000000007;
            public static void main(String[] args){
                Scanner sc=new Scanner(System.in);
                int t=sc.nextInt();
                while(t-->0){
                    int n=sc.nextInt(), k=sc.nextInt();
                    System.out.println(powMod(n,k));
                }
                
            }
     public static long powMod(int n, int k){
         if(k==0) return 1;
         long x=powMod(n, k/2);
         if(k%2==1) return(x*x%m)*n%m;
         return x*x%m;
     }       
}
