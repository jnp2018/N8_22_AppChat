
import java.util.*;

public class BaiU {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int c[][] = new int[1001][1001];
        char a[] = in.nextLine().toCharArray();
        char b[] = in.nextLine().toCharArray();
        for (int i = 0; i < 1001; i++) {
            for (int j = 0; j < 1001; j++) {
                c[i][j] = 0;
            }
        }
        for (int i = 1; i <= a.length; i++) {
            for (int j = 1; j <= b.length; j++) {
                if (a[i - 1] == b[j - 1]) {
                    c[i][j] = c[i - 1][j - 1] + 1;
                } else {
                    c[i][j] = Math.max(c[i - 1][j], c[i][j - 1]);
                }
            }
        }
        System.out.println(c[a.length][b.length]);
    }
}
