
import java.util.*;

public class BaiE {

    public static int n;
    public static int k;
    public static int count = 0;
    public static int A[];
    public static int B[];
    public static int C[];

    public static void queen(int i) {
        for (int j = 0; j < n; j++) {
            if (A[j] == 1 && B[i + j] == 1 && C[i - j + n] == 1) {
                A[j] = 0;
                B[i + j] = 0;
                C[i - j + n] = 0;
                if (i == n - 1) {
                    count++;
                } else {
                    queen(i + 1);
                }
                A[j] = 1;
                B[i + j] = 1;
                C[i - j + n] = 1;
            }
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        n = Integer.parseInt(in.nextLine());
        A = new int[n];
        B = new int[2 * n];
        C = new int[2 * n];
        for (int i = 0; i < n; i++) {
            A[i] = 1;
        }
        for (int i = 0; i < 2 * n; i++) {
            C[i] = 1;
            B[i] = 1;
        }
        queen(0);
        System.out.println(count);
    }
}
