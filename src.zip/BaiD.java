
import java.util.Scanner;

public class BaiD {
	static boolean check = true;
	private static Scanner sc;

	static void init(int n, int X[]) {
		for (int i = 0; i < n; i++) {
			X[i] = 0;
		}
	}

	// thuật toán sinh nhị phân
	static int[] nextBitString(int n, int X[],int k) {
		int []y = new int [n];
		int i = n - 1;
		while (i >= 0 && X[i] != 0) {
			X[i] = 0;
			i--;
		}
		if (i >= 0) {
			X[i] = 1;
		} else {
			check = false;
		}
		int dem = 0;
		for (int j = 0; j < n; j++) {
			if (X[j]==1) {
				dem++;
			}
		}
		if (dem==k) {
			y = X;
			return y;
		}else{
			return null;
		}
		
	}

	static void result(int n, int X[]) {
		for (int i = 0; i < n; i++) {
			if (i == X.length - 1) {
				System.out.print(X[i]);
			} else {
				System.out.print(X[i]);
			}
		}
		System.out.println();
	}

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		int t =0;
		int b = sc.nextInt();
		/*while (b>20||b<=0) {
			b = sc.nextInt();
		}*/
		while (t<b) {
			
			int n = sc.nextInt();
			int k = sc.nextInt();
			/*while (k<1||k>n||n>16) {
				n = sc.nextInt();
				k = sc.nextInt();
			}*/
			int[] X = new int[n];
			init(n, X);
			int r [] = new int[n];
			while (check) {
				 r  = nextBitString(n, X,k);
				 if (r!=null) {
					 result(n, r);
				}
			}
			check = true;
			t++;
		}

	}
}
