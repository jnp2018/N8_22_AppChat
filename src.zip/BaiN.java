import java.util.Scanner;

public class BaiN {
	private static Scanner sc;
	static String binarySearch(int x[],int l,int r,int key){
		while (l <= r) {
			int m = l + (r-l)/2;
			if (x[m] == key) return String.valueOf(m+1);
			if (x[m] < key){
				l = m + 1;
			}else{
				r = m - 1;
			}
		}
		return "NO"; 
	}
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		int t = 0 ;
		int b = sc.nextInt();
		while (t<b) {
			int n = sc.nextInt();
			int key = sc.nextInt();
			int []x = new int[n];
			for (int i = 0; i <n; i++) {
				x[i] = sc.nextInt();
			}
			System.out.println(binarySearch(x, 0, n-1,key));
			t++;
		}
		
	}
}
