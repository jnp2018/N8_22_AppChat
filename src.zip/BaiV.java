
import java.util.*;

public class BaiV {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String tmp[] = in.nextLine().split(" ");
        int n = Integer.parseInt(tmp[0]);
        int s = Integer.parseInt(tmp[1]);
        String num[] = in.nextLine().split(" ");
        int a[] = new int[n + 2];
        for (int i = 1; i <= n; i++) {
            a[i] = Integer.parseInt(num[i - 1]);
        }
        int L[][] = new int[n + 1][s + 1];
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= s; j++) {
                L[i][j] = 0;
            }
        }
        for (int i = 0; i <= n; i++) {
            L[i][0] = 1;
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= s; j++) {
                if (j >= a[i]) {
                    if (L[i - 1][j] == 1 || L[i - 1][j - a[i]] == 1) {
                        L[i][j] = 1;
                    } else {
                        L[i][j] = L[i - 1][j];
                    }
                }
            }
        }
        if (L[n][s] == 0) {
            System.out.println("NO");
        } else {
            System.out.println("YES");
        }
    }
}
