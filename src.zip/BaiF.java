
import java.util.*;

public class BaiF {
    
    public static int n;
    public static int k;
    public static int s;
    public static int count;
    public static int arr[];
    
    public static void check() {
        if (Arrays.stream(arr).sum() == s) {
            count++;
        }
    }
    
    public static void backtrack(int i) {
        for (int j = arr[i - 1] + 1; j <= n - k + i; j++) {
            arr[i] = j;
            if (i == k) {
                check();
            } else {
                backtrack(i + 1);
            }
        }
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<String> data = new ArrayList<>();
        while (true) {
            String tmp = in.nextLine();
            if (tmp.equals("0 0 0")) {
                break;
            }
            data.add(tmp);
        }
        for (String d : data) {
            String tmp[] = d.split(" ");
            n = Integer.parseInt(tmp[0]);
            k = Integer.parseInt(tmp[1]);
            s = Integer.parseInt(tmp[2]);
            count = 0;
            arr = new int[k + 1];
            arr[0] = 0;
            backtrack(1);
            System.out.println(count);
        }
        
    }
}
