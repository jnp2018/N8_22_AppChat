import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class BaiP {
	static Scanner sc;
	static void select(Queue<Integer> queue,int s){
		switch (s) {
		case 1:
			System.out.println(queue.size());
			break;
		case 2:
			if (queue.isEmpty()) {
				System.out.println("YES");
			}else{
				System.out.println("NO");
			}
			break;
		case 3:
			int n = sc.nextInt();
			queue.add(n);
			break;
		case 4:
			if (!queue.isEmpty()) {
				queue.remove();
			}
			break;
		case 5:
			if (!queue.isEmpty()) {
				System.out.println(queue.element());
			}else{
				System.out.println("-1");
			}
			break;
		case 6:
			if (!queue.isEmpty()) {
				int dem = 0;
				for (Integer i : queue) {
					dem++;
					if (dem==queue.size()) {
						System.out.println(i);
					}
				}
			}else{
				System.out.println("-1");
			}
			break;
		}
	}
	static Queue<Integer> queue = new LinkedList<>();
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		int t = 0;
		int n = sc.nextInt();
		while (t<n) {
			int l = sc.nextInt();
			for (int i = 0; i < l; i++) {
				int v = sc.nextInt();
				select(queue, v);
			}
			t++;
		}
		
	}
	
}
