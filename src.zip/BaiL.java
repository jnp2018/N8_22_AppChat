
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class BaiL {
    static long F[]=new long[100];
    public static void main(String[] args){
        F[1]=1;
        F[2]=1;
        for(int i=3; i<93; i++)
            F[i]=F[i-1]+F[i-2];
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        while(t-->0){
            int n=sc.nextInt();
            long i=sc.nextLong();
            System.out.println(fiboword(n,i));
        }
    }
    public static String fiboword(int n, long i){
        if(n==1) return "A";
        if(n==2) return "B";
        if(i<=F[n-2]) return fiboword(n-2,i);
        return fiboword(n-1, i-F[n-2]); 
    }
}
