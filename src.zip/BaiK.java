
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class BaiK {
    static long m=123456789;
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        while(t-->0){
            long n=sc.nextLong();
            System.out.println(powMod(2, n-1));
        }
    }
    public static long powMod(int n, long k){
        if(k==0) return 1;
        long x=powMod(n, k/2);
        if(k%2==1) return(x*x%m)*n%m;
        return x*x%m;
    }
}
